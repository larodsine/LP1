#ifndef FUNCTION_H
#define FUNCTION_H

#include <utility>
using std::pair;

std::pair<int, int> min_max( int V[], size_t n );

#endif
