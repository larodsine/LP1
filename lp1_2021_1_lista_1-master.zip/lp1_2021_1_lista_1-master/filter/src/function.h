#ifndef FUNCTION_H
#define FUNCTION_H
int * filter( int *, int * );
#endif
