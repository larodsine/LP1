﻿# Identificação Pessoal

Preencha os dados abaixo para identificar a autoria do trabalho.

- Nome: *\<insira seu nome aqui>*
- Email: *\<insira seu email aqui>*
- Turma: *\<insira sua turma aqui>*

# Questões Finalizadas

- [ ] Negativos 5
- [ ] Soma Vizinhos
- [ ] Intervalos
- [ ] Fibonacci
- [ ] Minmax
- [ ] Inverter
- [ ] Filtragem
- [ ] Ponto em Retângulo 1
- [ ] Ponto em Retângulo 2


--------
&copy; DIMAp/IMD/UFRN 2021.
