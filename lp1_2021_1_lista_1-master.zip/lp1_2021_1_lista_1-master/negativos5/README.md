# Negativos 5

Escreva um programa em C++ que recebe 5 valores inteiros da entrada padrão, conta quantos destes valores são negativos e imprime esta informação na sada padrão. Veja abaixo exemplo de entrada e sada esperada.

## Exemplos de Entrada/Saída


Entrada | Saída
------- | -----
`-1 -2 0 1 2` | `2`
`1 2 3 4 5` | `0`

## Conchecimentos Necessários

Leitura e escrita da entrada padrão, laços e condicionais
