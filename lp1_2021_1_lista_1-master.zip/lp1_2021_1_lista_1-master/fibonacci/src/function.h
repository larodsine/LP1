#ifndef FUNCTION_H
#define FUNCTION_H

#include <vector>
using std::vector;

std::vector<unsigned int> fib_below_n( unsigned int n );

#endif
